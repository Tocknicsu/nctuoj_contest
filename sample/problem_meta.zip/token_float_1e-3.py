import sys, os, re, math

try:
    ans = open(sys.argv[1],'rt')
    out = open(sys.argv[2],'rt')
    ans = re.split('\s+',ans.read())
    out = re.split('\s+',out.read())
    ans.pop() # Pop the last empty string
    out.pop() # Pop the last empty string
    ans = list(map(float,ans))
    out = list(map(float,out))
    pairs = zip(ans,out)
    for _ in pairs:
        if math.fabs(_[0]-_[1]) > 1e-3:
            raise
    print('AC 1.0')
except:
    print('WA 0.0')

verdict.cpp
